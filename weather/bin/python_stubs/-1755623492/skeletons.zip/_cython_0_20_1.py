# encoding: utf-8
# module _cython_0_20_1
# from /usr/lib/python2.7/dist-packages/lxml/objectify.so
# by generator 1.138
# no doc
# no imports

# no functions
# classes

class cython_function_or_method(object):
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __get__(self, obj, type=None): # real signature unknown; restored from __doc__
        """ descr.__get__(obj[, type]) -> value """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    func_closure = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_defaults = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_dict = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_globals = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __annotations__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __closure__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __code__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __defaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __globals__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __kwdefaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __qualname__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __self__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is ''
    __name__ = 'cython_function_or_method'


class generator(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def next(self): # real signature unknown; restored from __doc__
        """ x.next() -> the next value, or raise StopIteration """
        pass

    def send(self, *args, **kwargs): # real signature unknown
        pass

    def throw(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self): # real signature unknown; restored from __doc__
        """ x.__iter__() <==> iter(x) """
        pass

    gi_running = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



