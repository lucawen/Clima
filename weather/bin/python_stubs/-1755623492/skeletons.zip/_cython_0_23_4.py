# encoding: utf-8
# module _cython_0_23_4
# from /usr/local/lib/python2.7/dist-packages/pandas/tslib.so
# by generator 1.138
# no doc
# no imports

# no functions
# classes

class cython_function_or_method(object):
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __get__(self, obj, type=None): # real signature unknown; restored from __doc__
        """ descr.__get__(obj[, type]) -> value """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __reduce__(self, *args, **kwargs): # real signature unknown
        pass

    def __repr__(self): # real signature unknown; restored from __doc__
        """ x.__repr__() <==> repr(x) """
        pass

    func_closure = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_defaults = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_dict = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_globals = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __annotations__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __closure__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __code__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __defaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __globals__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __kwdefaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __qualname__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __self__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is ''
    __name__ = 'cython_function_or_method'


class fused_cython_function(cython_function_or_method):
    def __call__(self, *more): # real signature unknown; restored from __doc__
        """ x.__call__(...) <==> x(...) """
        pass

    def __getitem__(self, y): # real signature unknown; restored from __doc__
        """ x.__getitem__(y) <==> x[y] """
        pass

    def __get__(self, obj, type=None): # real signature unknown; restored from __doc__
        """ descr.__get__(obj[, type]) -> value """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    func_closure = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_code = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_defaults = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_dict = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_doc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_globals = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    func_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __annotations__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __closure__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __code__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __defaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __globals__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __kwdefaults__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __qualname__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __self__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __signatures__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default


    __dict__ = None # (!) real value is ''
    __name__ = 'fused_cython_function'


class generator(object):
    # no doc
    def close(self): # real signature unknown; restored from __doc__
        """ close() -> raise GeneratorExit inside generator. """
        pass

    def next(self): # real signature unknown; restored from __doc__
        """ x.next() -> the next value, or raise StopIteration """
        pass

    def send(self, arg): # real signature unknown; restored from __doc__
        """
        send(arg) -> send 'arg' into generator,
        return next yielded value or raise StopIteration.
        """
        pass

    def throw(self, typ, val=None, tb=None): # real signature unknown; restored from __doc__
        """
        throw(typ[,val[,tb]]) -> raise exception in generator,
        return next yielded value or raise StopIteration.
        """
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self): # real signature unknown; restored from __doc__
        """ x.__iter__() <==> iter(x) """
        pass

    gi_running = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    gi_yieldfrom = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """object being iterated by 'yield from', or None"""

    __qualname__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """qualified name of the generator"""


    __name__ = 'generator'


