# encoding: utf-8
# module _codecs_iso2022
# from /usr/lib/python2.7/lib-dynload/_codecs_iso2022.x86_64-linux-gnu_d.so
# by generator 1.138
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
