# encoding: utf-8
# module _codecs_tw
# from /usr/lib/python2.7/lib-dynload/_codecs_tw.x86_64-linux-gnu.so
# by generator 1.138
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_big5 = None # (!) real value is ''

__map_cp950ext = None # (!) real value is ''

