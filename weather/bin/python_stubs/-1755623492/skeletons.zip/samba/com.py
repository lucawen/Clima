# encoding: utf-8
# module samba.com
# from /usr/lib/python2.7/dist-packages/samba/com.so
# by generator 1.138
""" Simple COM implementation """
# no imports

# functions

def get_class_object(clsid, iid): # real signature unknown; restored from __doc__
    """ S.get_class_object(clsid, iid) -> instance """
    pass

# no classes
