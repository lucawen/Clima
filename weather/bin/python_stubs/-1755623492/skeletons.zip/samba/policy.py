# encoding: utf-8
# module samba.policy
# from /usr/lib/python2.7/dist-packages/samba/policy.so
# by generator 1.138
""" (Group) Policy manipulation """
# no imports

# Variables with simple values

GPLINK_OPT_DISABLE = 1
GPLINK_OPT_ENFORCE  = 2

GPO_FLAG_USER_DISABLE = 1

GPO_MACHINE_USER_DISABLE = 2

# functions

def ads_to_dir_access_mask(access_mask): # real signature unknown; restored from __doc__
    """ ads_to_dir_access_mask(access_mask) -> dir_mask """
    pass

def get_gplink_options(options): # real signature unknown; restored from __doc__
    """ get_gplink_options(options) -> list """
    return []

def get_gpo_flags(flags): # real signature unknown; restored from __doc__
    """ get_gpo_flags(flags) -> list """
    return []

# no classes
