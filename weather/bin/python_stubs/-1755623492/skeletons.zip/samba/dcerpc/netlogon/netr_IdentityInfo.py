# encoding: utf-8
# module samba.dcerpc.netlogon
# from /usr/lib/python2.7/dist-packages/samba/dcerpc/netlogon.so
# by generator 1.138
""" netlogon DCE/RPC """

# imports
import dcerpc as __dcerpc
import talloc as __talloc


class netr_IdentityInfo(__talloc.Object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    account_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    domain_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    logon_id_high = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    logon_id_low = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    parameter_control = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    workstation = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



