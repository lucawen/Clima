# encoding: utf-8
# module samba.dcerpc.netlogon
# from /usr/lib/python2.7/dist-packages/samba/dcerpc/netlogon.so
# by generator 1.138
""" netlogon DCE/RPC """

# imports
import dcerpc as __dcerpc
import talloc as __talloc


class netr_DELTA_ACCOUNT(__talloc.Object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    privilege_attrib = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    privilege_control = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    privilege_entries = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    privilege_name = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    quotalimits = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    sdbuf = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    SecurityInformation = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    system_flags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown1 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown2 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown3 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown4 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown5 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown6 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown7 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    unknown8 = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



