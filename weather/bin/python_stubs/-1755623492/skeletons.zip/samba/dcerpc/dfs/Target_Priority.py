# encoding: utf-8
# module samba.dcerpc.dfs
# from /usr/lib/python2.7/dist-packages/samba/dcerpc/dfs.so
# by generator 1.138
""" dfs DCE/RPC """

# imports
import dcerpc as __dcerpc
import talloc as __talloc


class Target_Priority(__talloc.Object):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    reserved = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    target_priority_class = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    target_priority_rank = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



