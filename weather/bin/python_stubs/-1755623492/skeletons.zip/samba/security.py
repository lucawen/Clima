# encoding: utf-8
# module samba.security
# from /usr/lib/python2.7/dist-packages/samba/security.so
# by generator 1.138
""" Security support. """
# no imports

# functions

def access_check(security_descriptor, token, access_desired): # real signature unknown; restored from __doc__
    """ access_check(security_descriptor, token, access_desired) -> access_granted.  Raises NT_STATUS on error, including on access check failure, returns access granted bitmask """
    pass

# no classes
